<h1>week 3</h1>

<p>
  use <a href="https://www.w3schools.com">w3schools<a>
  or <a href="https://www.php.net/manual/">php manual</a>
  for search how php functions work
</p>

<h2>some examples with built-in functions</h2>
<h3>
<?php
$string_1 = "Built in <span style='color:red'>strlen(parameter)</span> function returns
the length of the string sent as a parameter.";
$string_2 = "PHP scripts can only be interpreted on a server that has PHP installed.";

echo $string_1;
echo "<br>";
echo $string_2;
echo "<br>";
echo "The first string has: ".strlen($string_1)." symbols.";
echo "<br>";
echo "The second string has: ".strlen($string_2)." symbols.";

#$div = $dochtml->getElementBy('div2')->nodeValue;

?>
</h3>
