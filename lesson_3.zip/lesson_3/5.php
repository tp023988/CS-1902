<?php
  function function_1()
  {
    $text_0 = "<h1>week 3</h1>";
    $text_1 = "use <a href='https://www.w3schools.com'>w3schools<a>
    or <a href='https://www.php.net/manual/'>php manual</a>
    for search how php functions work.";
    echo $text_0;
    echo "<br><br>";
    echo $text_1;
    echo "<br><br><br>";
    $text_2 = "&copy Astana IT University.";
    echo $text_2;
  }
  function_1();

  $enterprise_value = "IT courses";
  function_2($enterprise_value);

  function function_2($enterprise_name)
  {
    echo "<br><br><br>";
    $text_3 = "&copy".$enterprise_name.".";
    echo $text_3;
  }

  $text_1 = "IT";
  $text_2 = "IT courses";
  $text_3 = "Built in <span style='color:red'>strlen(parameter)</span> function returns
  the length of the string sent as a parameter.";

  echo function_3($text_1);

  function function_3($entered_user_name)
  {
    if(strlen($entered_user_name) > 2 && strlen($entered_user_name) < 20)
    {
      echo "<br>";
      return "The length of the input name is fine.";
    }
    else if (strlen($entered_user_name) <= 2)
    {
      echo "<br>";
      return "The length must be larger than 2 symbols.";
    }
    else
    {
      echo "<br>";
      return "The length must be less than 20 symbols.";
    }
  }
?>
