<!doctype html>
<html>
  <form action="http://localhost/lesson_3/8_4.php" method="GET">
    <p>What is your favourite programming language?</p>
    <input type="text" name="languageName" id="languageId"/>
    <p>What is the popular trend of IT nowadays?</p>
    <input type="text" name="trendName" id="trendId"/>
    <?php echo "<br><br>"; ?>
    <input type="submit"/>
  </form>
</html>
