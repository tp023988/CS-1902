<?php
  function function_1()
  {
    $text_0 = "<h1>week 3</h1>";
    $text_1 = "use <a href='https://www.w3schools.com'>w3schools<a>
    or <a href='https://www.php.net/manual/'>php manual</a>
    for search how php functions work";
    echo $text_0;
    echo "<br><br>";
    echo $text_1;
    echo "<br><br><br>";
    $text_2 = "&copy Astana IT University.";
    echo $text_2;
  }
  function_1();
?>
