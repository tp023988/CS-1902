<!doctype html>
<html>
<?php

  if(isset($_GET["userName"]))
  {
    echo "This parameter exists";
  }
  else
  {
    echo "This parameter does not exist";
  }
  echo "<br><br>";
  if(isset($_GET["languageName"]) && isset($_GET["trendName"]))
  {
    echo "I am a ".$_GET["languageName"]." developer. <br>";
    echo "<br><br>";
    if($_GET["languageName"] == $_GET["trendName"])
    {
      echo "Luckily, ".$_GET["trendName"]." is very popular nowadays.";
    }
    else
    {
      echo "However, ".$_GET["trendName"]." is more popular nowadays.";
    }
  }

?>
</html>
