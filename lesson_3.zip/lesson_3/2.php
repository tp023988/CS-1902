<h1>week 3</h1>

<?php
  function_1();
?>
<p>
  use <a href="https://www.w3schools.com">w3schools<a>
  or <a href="https://www.php.net/manual/">php manual</a>
  for search how php functions work.
</p>

<h2>an example of a function</h2>
<h3>
  <?php

  function_1();
  function_1();

  function function_1()
  {
    echo "<br>";
    $text_1 = "use <a href='https://www.w3schools.com'>w3schools<a>
    or <a href='https://www.php.net/manual/'>php manual</a>
    for search how php functions work";
    echo $text_1;
    echo "<br>";
    $text_2 = "&copy Astana IT University.";
    echo $text_2;
  }
  ?>
</h3>
