<!doctype html>
<html>

<form>
  <input type="text" name="username" size="100"/>
  <br>
  <input type="submit" />
</form>

<?php

  print_r($_GET);

?>

</html>
