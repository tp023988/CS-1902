<h1>numbers 2</h1>

<h2>
<?php
$number_1 = 15;
$number_2 = 14.99;
#output:
            #15 - 14.99 = 0.01
print($number_1." - ".$number_2." = ");
print($number_1 - $number_2);
print("<br>");


$number_3 = 15.07;
$number_4 = 14.002;
#printf("%.*f", $number_3);print("<br>");
#printf("%.*f", $number_4);print("<br>");

print($number_1." - ".$number_2." = ");
print($number_1 - $number_2);
$number_3 = $number_1 - $number_2;
print("<br>");
printf("%.2f", $number_3);
print("<br>");
print($number_1." + ".$number_2." = ");
print($number_1 + $number_2);
print("<br>");
print($number_1." * ".$number_2." = ");
print($number_1 * $number_2);
print("<br>");
print($number_1." / ".$number_2." = ");
print($number_1 / $number_2);

?>
</h2>

<a href="https://www.rapidtables.com/convert/number/decimal-to-binary.html" target="_blank">link</a>
<!--
0.0000001010001111011
0.0000001010001111011
-->
