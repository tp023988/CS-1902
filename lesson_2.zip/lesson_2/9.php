<h1>another way to print</h1>

<h2>
<?php

$str1 = 'Trimester';

?>

<?php echo $str1; ?>
<?php echo "<br>"; ?>
<?=$str1?>
</h2>
