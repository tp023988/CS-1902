<h1>numbers 1</h1>

<h2>
<?php
$number_1 = 15;
$number_2 = 14.99;

echo $number_1;

echo '<br>';

echo $number_2;

?>
</h2>
