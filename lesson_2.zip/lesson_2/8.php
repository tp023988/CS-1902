<h1>echo() function</h1>

<h2> echo 1<br>
<?php

$str1 = 'hello';
$str2 = 'guys';

echo $str1;
echo ' ';
echo $str2;

echo '<br>echo 2<br>';
echo $str1, "&nbsp", $str2;

echo '<br>echo()<br>';
echo ($str1);
echo (' ');
echo ($str2);

?>
</h2>
