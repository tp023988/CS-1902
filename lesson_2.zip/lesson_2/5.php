<?php
print 'conca'.'tenation';
?>
