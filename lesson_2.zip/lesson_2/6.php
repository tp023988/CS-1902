<h1>variables</h1>

<?php

$a = 'b';
$A = 'B';

echo "$a";

echo "<br>";

echo "$A";

?>
