<h1>comments</h1>

<h2>
<?php
echo "comment 1";
//echo "you won't see this line 1";
echo "comment 2";
#echo "you won't see this line 2";
echo "comment 3";
/*
echo "you won't see this line 3";
echo "you won't see this line 4";
*/
?>
</h2>
