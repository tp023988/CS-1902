<?php
$var_1<<<htmltag
<h1>hello</h1>
htmltag;
echo $var_1;
?>
