<?php
$sample = "Sample Text To Be Tested";
echo "before:";
echo strtolower($sample);
echo "<br>";
echo "after:";
echo strtoupper($sample);
echo "<br>";
?>
