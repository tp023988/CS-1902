<h1>printf() function</h1>

<h2>
<?php

$str1 = 'hello';
$str3 = ' world';
$str2 = 'guys';
$int_v = '35.1935';

#$int_v_1 = '35.53400';
#$int_v_2 = '35.53450';

echo($str1.$str3.' and '.$str2." I"." am ".$int_v);
print("<br>");
printf('%s world and %s I am %.1f', $str1, $str2, $int_v);
print("<br>");
printf('%s world and %s I am %d', $str1, $str2, $int_v);
?>
</h2>
