<?php
print<<<htmlblock
<html>
<head>
<title>the block</title>
</head>
<body>
<h1>hello</h1>
</body>
</html>
htmlblock
?>
