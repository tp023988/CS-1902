<h1>hello html world</h1>
<h1 style="color:red">hello css world</h1>
<h1><?php echo "hello php world 1"; ?></h1>
<h1><?="hello php world 2"; ?></h1>
