<h1>hello html world</h1>
<h1 style="color:red">hello css world</h1>
<h1><?php echo "hello php world 1"; ?></h1>
<h1><?="hello php world 2"; ?></h1>
<h1><?php print "hello php world 3"; ?></h1>
<h1><?php print 'hello php\'s world'; ?></h1>
<?php print '<h2 style="color:red"> hello php in html world </h2>' ?>
