<h1>numbers 2</h1>

<h2>
<?php
$number_1 = 2;
$number_2 = 8;

print($number_1." ** ".$number_2." = ");
print($number_1 ** $number_2);
print("<br>");
print("(".$number_2." +1) % ".$number_1." = ");
print(($number_2+1) % $number_1);
print("<br>");
print("(".$number_2." +1) / ".$number_1." = ");
$number_3 = ($number_2+1) / $number_1;
printf('%.1f', $number_3);
print("<br>");
/*
print($number_1." + ".$number_2." = ");
print($number_1 + $number_2);
print("<br>");
print($number_1." * ".$number_2." = ");
print($number_1 * $number_2);
print("<br>");
print($number_1." / ".$number_2." = ");
print($number_1 / $number_2);
*/
?>
</h2>
