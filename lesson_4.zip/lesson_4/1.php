<?php
  echo "require: <br>";
  require '2.php';
  echo "<br>";
  echo "include: <br>";
  include '2.php';
  echo "<br>";
  echo "some goodbye text";
?>
