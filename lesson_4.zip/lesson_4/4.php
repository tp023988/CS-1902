<form action="5.php" method="post">
  <input type="text" name="articleTitle" placeholder="Please enter the title" size="102">
  <br><br>
  <input type="text" name="articleURL" placeholder="Please enter the url" size="102">
  <br><br>
  <textarea name="articleContent" rows="20" cols="100">

  </textarea>
  <br><br>
  <input type="date" name="articleDate" placeholder="Please enter the url" size="102">
  <br><br>
  <input type="submit">
</form>
