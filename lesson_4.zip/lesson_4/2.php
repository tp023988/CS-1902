<?php
  echo "file 2";
?>
